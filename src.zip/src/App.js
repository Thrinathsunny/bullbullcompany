
import './App.css';
import Card from './component/card';
function App() {
  return (
    <div className="App">
     <Card/>
    </div>
  );
}

export default App;
